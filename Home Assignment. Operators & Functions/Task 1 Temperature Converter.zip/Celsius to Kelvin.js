function convertToKelvin(tempCelsius){
    let tempKelvin = (tempCelsius + 273.15);
    return tempKelvin;
}
console.log(convertToKelvin(35)); // 308.15